function calcNetProfit() {
    var expectedGain = document.getElementById('gain').value;
    var expectedCost = document.getElementById('cost').value;
    var netProfit = expectedGain - expectedCost;

    document.getElementById('netprofit').value = netProfit;
    return netProfit;
}
function calcReturnOnInvestment() {
    var expectedCost = document.getElementById('cost').value;
    var netProfit = calcNetProfit();
    var roi = netProfit / expectedCost * 100; // Calculate Return on Investment
    document.getElementById('roi').value = roi;
}
